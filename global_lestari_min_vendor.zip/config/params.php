<?php

return [
    'adminEmail' => 'adm.gmotorindo@gmail.com',
];