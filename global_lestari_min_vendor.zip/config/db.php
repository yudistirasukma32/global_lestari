<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=global_lestari',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8',
];
