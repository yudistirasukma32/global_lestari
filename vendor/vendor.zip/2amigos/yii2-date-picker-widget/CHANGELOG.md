# Changelog

## 1.0.5 - 2015-04-02

## Changed 
- Added CHANGELOG.md file

## Fixed 
- Fixed asset registration bug when using form
